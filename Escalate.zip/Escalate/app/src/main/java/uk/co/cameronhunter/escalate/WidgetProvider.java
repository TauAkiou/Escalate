package uk.co.cameronhunter.escalate;

import android.appwidget.AppWidgetProvider;

public class WidgetProvider extends AppWidgetProvider {

}
